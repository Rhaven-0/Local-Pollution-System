<?php
require 'config.php';
redirectIfNotLoggedIn();
redirectIfNotAdmin();

// Handle status updates with logging
if (isset($_POST['update_status'])) {
    $report_id = (int) $_POST['report_id'];
    $new_status = trim($_POST['new_status']);
    $admin_notes = isset($_POST['admin_notes']) ? trim($_POST['admin_notes']) : '';
    $admin_id = $_SESSION['user_id'];
    
    $valid_statuses = ['pending', 'under_investigation', 'action_taken', 'resolved', 'rejected', 'approved'];
    
    if (in_array($new_status, $valid_statuses)) {
        // Get old status before update
        $old_stmt = $conn->prepare("SELECT status FROM reports WHERE id = :id");
        $old_stmt->execute([':id' => $report_id]);
        $old_status = $old_stmt->fetchColumn();
        
        // Update report
        $stmt = $conn->prepare("UPDATE reports SET status = :status, admin_notes = :notes WHERE id = :id");
        $stmt->execute([
            ':status' => $new_status,
            ':notes' => $admin_notes,
            ':id' => $report_id
        ]);
        
        // Log the action
        $log_stmt = $conn->prepare("
            INSERT INTO admin_logs (admin_id, report_id, action, old_status, new_status, notes)
            VALUES (:admin_id, :report_id, 'status_updated', :old_status, :new_status, :notes)
        ");
        $log_stmt->execute([
            ':admin_id' => $admin_id,
            ':report_id' => $report_id,
            ':old_status' => $old_status,
            ':new_status' => $new_status,
            ':notes' => $admin_notes
        ]);
        
        header("Location: adminDashboard.php");
        exit();
    }
}

// Handle validation submission
if (isset($_POST['submit_validation'])) {
    $report_id = (int) $_POST['report_id'];
    $admin_id = $_SESSION['user_id'];
    
    $photo_attached = isset($_POST['photo_attached']) ? 1 : 0;
    $location_valid = isset($_POST['location_valid']) ? 1 : 0;
    $description_adequate = isset($_POST['description_adequate']) ? 1 : 0;
    $severity_appropriate = isset($_POST['severity_appropriate']) ? 1 : 0;
    $no_duplicates = isset($_POST['no_duplicates']) ? 1 : 0;
    $validation_notes = isset($_POST['validation_notes']) ? trim($_POST['validation_notes']) : '';
    
    // All checks must pass
    $overall_valid = ($photo_attached && $location_valid && $description_adequate && $severity_appropriate && $no_duplicates) ? 1 : 0;
    
    // Save validation checklist
    $val_stmt = $conn->prepare("
        INSERT INTO validation_checklist 
        (report_id, admin_id, photo_attached, location_valid, description_adequate, severity_appropriate, no_duplicates, overall_valid, validation_notes)
        VALUES (:rid, :aid, :pa, :lv, :da, :sa, :nd, :ov, :vn)
    ");
    $val_stmt->execute([
        ':rid' => $report_id,
        ':aid' => $admin_id,
        ':pa' => $photo_attached,
        ':lv' => $location_valid,
        ':da' => $description_adequate,
        ':sa' => $severity_appropriate,
        ':nd' => $no_duplicates,
        ':ov' => $overall_valid,
        ':vn' => $validation_notes
    ]);
    
    // If validation passed, auto-approve and mark as verified
    if ($overall_valid) {
        $old_stmt = $conn->prepare("SELECT status FROM reports WHERE id = :id");
        $old_stmt->execute([':id' => $report_id]);
        $old_status = $old_stmt->fetchColumn();
        
        $upd_stmt = $conn->prepare("
            UPDATE reports 
            SET status = 'approved', is_verified = 1, verified_at = NOW(), verified_by = :aid
            WHERE id = :id
        ");
        $upd_stmt->execute([':aid' => $admin_id, ':id' => $report_id]);
        
        // Log the validation
        $log_stmt = $conn->prepare("
            INSERT INTO admin_logs (admin_id, report_id, action, old_status, new_status, notes)
            VALUES (:admin_id, :report_id, 'validated_approved', :old_status, 'approved', :notes)
        ");
        $log_stmt->execute([
            ':admin_id' => $admin_id,
            ':report_id' => $report_id,
            ':old_status' => $old_status,
            ':notes' => 'All validation checks passed'
        ]);
    } else {
        // Log validation failure
        $log_stmt = $conn->prepare("
            INSERT INTO admin_logs (admin_id, report_id, action, notes)
            VALUES (:admin_id, :report_id, 'validation_failed', :notes)
        ");
        $log_stmt->execute([
            ':admin_id' => $admin_id,
            ':report_id' => $report_id,
            ':notes' => 'Validation failed - some criteria not met'
        ]);
    }
    
    header("Location: adminDashboard.php");
    exit();
}

// Handle delete
if (isset($_GET['delete_report'])) {
    $id   = (int) $_GET['delete_report'];
    $admin_id = $_SESSION['user_id'];
    
    // Log the deletion
    $log_stmt = $conn->prepare("
        INSERT INTO admin_logs (admin_id, report_id, action, notes)
        VALUES (:admin_id, :report_id, 'deleted', 'Report deleted by admin')
    ");
    $log_stmt->execute([
        ':admin_id' => $admin_id,
        ':report_id' => $id
    ]);
    
    $stmt = $conn->prepare("DELETE FROM reports WHERE id = :id");
    $stmt->execute([':id' => $id]);
    header("Location: adminDashboard.php");
    exit();
}

$totalUsers   = $conn->query("SELECT COUNT(*) FROM users WHERE role = 'user'")->fetchColumn();
$totalReports = $conn->query("SELECT COUNT(*) FROM reports")->fetchColumn();
$pending      = $conn->query("SELECT COUNT(*) FROM reports WHERE status = 'pending'")->fetchColumn();
$investigating = $conn->query("SELECT COUNT(*) FROM reports WHERE status = 'under_investigation'")->fetchColumn();
$action_taken = $conn->query("SELECT COUNT(*) FROM reports WHERE status = 'action_taken'")->fetchColumn();
$resolved     = $conn->query("SELECT COUNT(*) FROM reports WHERE status = 'resolved'")->fetchColumn();

$stmt = $conn->prepare("
    SELECT r.*, u.username
    FROM reports r
    JOIN users u ON r.user_id = u.id
    ORDER BY r.created_at DESC
");
$stmt->execute();
$reports = $stmt->fetchAll();

$stmt = $conn->prepare("SELECT * FROM users WHERE role = 'user' ORDER BY created_at DESC");
$stmt->execute();
$users = $stmt->fetchAll();

// Fetch admin activity logs
$log_stmt = $conn->prepare("
    SELECT al.*, u.username, r.title
    FROM admin_logs al
    LEFT JOIN users u ON al.admin_id = u.id
    LEFT JOIN reports r ON al.report_id = r.id
    ORDER BY al.created_at DESC
    LIMIT 100
");
$log_stmt->execute();
$activity_logs = $log_stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard — AirWatch</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">

    <div class="topnav">
        <div class="brand">🌿 AirWatch — Admin Panel</div>
        <div class="user-info">
            Logged in as <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
            &nbsp;|&nbsp;
            <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
        </div>
    </div>

    <div class="stats-grid">
        <div class="stat-card">
            <div class="num"><?php echo $totalUsers; ?></div>
            <div class="label">Total Users</div>
        </div>
        <div class="stat-card">
            <div class="num"><?php echo $totalReports; ?></div>
            <div class="label">Total Reports</div>
        </div>
        <div class="stat-card">
            <div class="num"><?php echo $pending; ?></div>
            <div class="label">Pending</div>
        </div>
        <div class="stat-card">
            <div class="num"><?php echo $investigating; ?></div>
            <div class="label">Investigating</div>
        </div>
        <div class="stat-card">
            <div class="num"><?php echo $action_taken; ?></div>
            <div class="label">Action Taken</div>
        </div>
        <div class="stat-card">
            <div class="num"><?php echo $resolved; ?></div>
            <div class="label">Resolved</div>
        </div>
    </div>

    <div class="tabs">
        <button class="tab-btn active" onclick="switchTab('reports', this)">📋 Reports</button>
        <button class="tab-btn" onclick="switchTab('users', this)">👥 Users</button>
        <button class="tab-btn" onclick="switchTab('activity', this)">📊 Activity Log</button>
    </div>

    <!-- Reports Tab -->
    <div id="tab-reports" class="tab-content active">
        <div class="card">
            <div class="card-header">All Pollution Reports</div>
            <div class="card-body" style="padding: 0;">
                <table>
                    <thead>
                        <tr>
                            <th>Photo</th>
                            <th>Title</th>
                            <th>Type</th>
                            <th>Severity</th>
                            <th>Submitted By</th>
                            <th>Location</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($reports)): ?>
                        <tr><td colspan="9" class="text-center text-muted">No reports yet.</td></tr>
                        <?php else: ?>
                        <?php foreach ($reports as $r): ?>
                        <tr>
                            <td>
                                <?php if ($r['photo']): ?>
                                    <img src="uploads/<?php echo htmlspecialchars($r['photo']); ?>"
                                         class="photo-thumb" alt="photo">
                                <?php else: ?>
                                    <span class="text-muted">None</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($r['title']); ?></td>
                            <td>
                                <?php 
                                    $types = [
                                        'Air' => '🌫️',
                                        'Water' => '💧',
                                        'Noise' => '🔊',
                                        'Waste' => '🗑️',
                                        'Chemical' => '☢️',
                                        'Soil' => '⛰️',
                                        'Other' => '⚠️'
                                    ];
                                    $type = $r['pollution_type'] ?? 'Unknown';
                                    echo ($types[$type] ?? '•') . ' ' . htmlspecialchars($type);
                                ?>
                            </td>
                            <td>
                                <?php 
                                    $severities = [
                                        'Low' => '🟢',
                                        'Medium' => '🟡',
                                        'High' => '🔴'
                                    ];
                                    $severity = $r['severity_level'] ?? 'Unknown';
                                    echo ($severities[$severity] ?? '•') . ' ' . htmlspecialchars($severity);
                                ?>
                            </td>
                            <td><?php echo htmlspecialchars($r['username']); ?></td>
                            <td><?php echo htmlspecialchars($r['location'] ?? '—'); ?></td>
                            <td><?php echo date('M d, Y', strtotime($r['created_at'])); ?></td>
                            <td>
                                <span class="badge badge-<?php echo $r['status']; ?>">
                                    <?php echo ucfirst($r['status']); ?>
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-info" 
                                        onclick="openReviewModal(<?php echo $r['id']; ?>, <?php echo htmlspecialchars(json_encode($r)); ?>)">
                                    👁️ Review
                                </button>
                                <button class="btn btn-sm btn-primary" 
                                        onclick="openStatusModal(<?php echo $r['id']; ?>, '<?php echo $r['status']; ?>', <?php echo htmlspecialchars(json_encode($r['admin_notes'] ?? '')); ?>)">
                                    ⚙️ Status
                                </button>
                                <a href="adminDashboard.php?delete_report=<?php echo $r['id']; ?>"
                                   class="btn btn-sm btn-danger"
                                   onclick="return confirm('Delete this report permanently?');">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Users Tab -->
    <div id="tab-users" class="tab-content">
        <div class="card">
            <div class="card-header">Registered Users</div>
            <div class="card-body" style="padding: 0;">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Registered</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($users)): ?>
                        <tr><td colspan="4" class="text-center text-muted">No users yet.</td></tr>
                        <?php else: ?>
                        <?php foreach ($users as $u): ?>
                        <tr>
                            <td><?php echo $u['id']; ?></td>
                            <td><?php echo htmlspecialchars($u['username']); ?></td>
                            <td><?php echo htmlspecialchars($u['email']); ?></td>
                            <td><?php echo date('M d, Y', strtotime($u['created_at'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Activity Log Tab -->
    <div id="tab-activity" class="tab-content">
        <div class="card">
            <div class="card-header">📊 Admin Activity Log</div>
            <div class="card-body">
                <table>
                    <thead>
                        <tr>
                            <th>Timestamp</th>
                            <th>Admin</th>
                            <th>Action</th>
                            <th>Report</th>
                            <th>Old Status</th>
                            <th>New Status</th>
                            <th>Notes</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($activity_logs)): ?>
                        <tr><td colspan="7" class="text-center text-muted">No activity yet.</td></tr>
                        <?php else: ?>
                        <?php foreach ($activity_logs as $log): ?>
                        <tr style="background-color: <?php echo $log['action'] === 'deleted' ? '#ffebee' : ''; ?>">
                            <td style="font-size: 0.85rem;">
                                <?php echo date('M d, Y g:i A', strtotime($log['created_at'])); ?>
                            </td>
                            <td>
                                <strong><?php echo htmlspecialchars($log['username'] ?? 'System'); ?></strong>
                            </td>
                            <td>
                                <?php 
                                    $actions = [
                                        'status_updated' => '🔄 Status Updated',
                                        'validated_approved' => '✅ Validated & Approved',
                                        'validation_failed' => '❌ Validation Failed',
                                        'deleted' => '🗑️ Deleted',
                                        'reviewed' => '👁️ Reviewed'
                                    ];
                                    $action = $log['action'] ?? 'unknown';
                                    echo $actions[$action] ?? '📝 ' . ucfirst(str_replace('_', ' ', $action));
                                ?>
                            </td>
                            <td>
                                <?php if ($log['report_id']): ?>
                                    <span class="text-muted">Report #<?php echo $log['report_id']; ?></span>
                                    <?php if ($log['title']): ?>
                                        <br><small><?php echo htmlspecialchars(substr($log['title'], 0, 30)); ?></small>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($log['old_status']): ?>
                                    <span class="badge badge-<?php echo $log['old_status']; ?>" style="font-size: 0.75rem;">
                                        <?php echo ucfirst(str_replace('_', ' ', $log['old_status'])); ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($log['new_status']): ?>
                                    <span class="badge badge-<?php echo $log['new_status']; ?>" style="font-size: 0.75rem;">
                                        <?php echo ucfirst(str_replace('_', ' ', $log['new_status'])); ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                            <td style="font-size: 0.85rem; max-width: 250px;">
                                <?php if ($log['notes']): ?>
                                    <span style="color: #666;">
                                        <?php echo htmlspecialchars(substr($log['notes'], 0, 50)); ?>
                                        <?php if (strlen($log['notes']) > 50): ?>...<?php endif; ?>
                                    </span>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    </div>

    <!-- Status Update Modal -->
    <div id="status-modal" class="modal" style="display: none;">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Update Report Status</h2>
                <span class="modal-close" onclick="closeStatusModal()">&times;</span>
            </div>
            <div class="modal-body">
                <form method="POST" id="status-form">
                    <input type="hidden" name="report_id" id="report_id">
                    
                    <div class="form-group">
                        <label>New Status</label>
                        <select name="new_status" id="new_status" required>
                            <option value="">-- Select Status --</option>
                            <option value="pending">⏳ Pending</option>
                            <option value="under_investigation">🔍 Under Investigation</option>
                            <option value="action_taken">✅ Action Taken</option>
                            <option value="resolved">🎯 Resolved</option>
                            <option value="rejected">❌ Rejected</option>
                            <option value="approved">✨ Approved</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Admin Notes (optional)</label>
                        <textarea name="admin_notes" id="admin_notes" rows="4" 
                                  placeholder="Add notes about this report, actions taken, or reason for status change..."></textarea>
                    </div>

                    <div style="text-align: right; margin-top: 16px;">
                        <button type="button" class="btn btn-secondary" onclick="closeStatusModal()">Cancel</button>
                        <button type="submit" name="update_status" class="btn btn-primary">Update Status</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Report Review Modal -->
    <div id="review-modal" class="modal" style="display: none;">
        <div class="modal-content" style="max-width: 800px; max-height: 90vh; overflow-y: auto;">
            <div class="modal-header">
                <h2>Review Report Details</h2>
                <span class="modal-close" onclick="closeReviewModal()">&times;</span>
            </div>
            <div class="modal-body">
                <div id="review-content">
                    <!-- Content will be populated by JavaScript -->
                </div>
                <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #eee; text-align: right;">
                    <button type="button" class="btn btn-secondary" onclick="closeReviewModal()">Close</button>
                    <button type="button" class="btn btn-primary" id="validate-btn" onclick="openValidationModal()">✅ Proceed to Validation</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Validation Checklist Modal -->
    <div id="validation-modal" class="modal" style="display: none;">
        <div class="modal-content" style="max-width: 700px;">
            <div class="modal-header">
                <h2>Validation Checklist</h2>
                <span class="modal-close" onclick="closeValidationModal()">&times;</span>
            </div>
            <div class="modal-body">
                <form method="POST" id="validation-form">
                    <input type="hidden" name="report_id" id="validation_report_id">
                    <input type="hidden" name="submit_validation" value="1">
                    
                    <p style="color: #666; margin-bottom: 16px;">Review the following criteria before approving this report:</p>
                    
                    <div style="background-color: #f5f5f5; padding: 14px; border-radius: 6px; margin-bottom: 16px;">
                        <div style="margin-bottom: 12px;">
                            <label style="display: flex; align-items: center; cursor: pointer;">
                                <input type="checkbox" name="photo_attached" style="margin-right: 8px; width: 18px; height: 18px;">
                                <span><strong>📸 Photo Attached</strong> - Report has a clear photo/image</span>
                            </label>
                        </div>
                        <div style="margin-bottom: 12px;">
                            <label style="display: flex; align-items: center; cursor: pointer;">
                                <input type="checkbox" name="location_valid" style="margin-right: 8px; width: 18px; height: 18px;">
                                <span><strong>📍 Location Valid</strong> - Location is specific and verifiable</span>
                            </label>
                        </div>
                        <div style="margin-bottom: 12px;">
                            <label style="display: flex; align-items: center; cursor: pointer;">
                                <input type="checkbox" name="description_adequate" style="margin-right: 8px; width: 18px; height: 18px;">
                                <span><strong>📝 Description Adequate</strong> - Description is detailed and clear</span>
                            </label>
                        </div>
                        <div style="margin-bottom: 12px;">
                            <label style="display: flex; align-items: center; cursor: pointer;">
                                <input type="checkbox" name="severity_appropriate" style="margin-right: 8px; width: 18px; height: 18px;">
                                <span><strong>⚠️ Severity Appropriate</strong> - Severity level matches the issue</span>
                            </label>
                        </div>
                        <div>
                            <label style="display: flex; align-items: center; cursor: pointer;">
                                <input type="checkbox" name="no_duplicates" style="margin-right: 8px; width: 18px; height: 18px;">
                                <span><strong>🔄 No Duplicates</strong> - This is not a duplicate report</span>
                            </label>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Validation Notes (optional)</label>
                        <textarea name="validation_notes" id="validation_notes" rows="3" 
                                  placeholder="Add any additional notes about this validation..."></textarea>
                    </div>

                    <div style="text-align: right; margin-top: 16px;">
                        <button type="button" class="btn btn-secondary" onclick="closeValidationModal()">Cancel</button>
                        <button type="submit" class="btn btn-success">✅ Submit Validation</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <style>
        .modal { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; }
        .modal-content { background: white; border-radius: 8px; width: 90%; max-width: 600px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .modal-header { padding: 16px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center; }
        .modal-header h2 { margin: 0; font-size: 1.3rem; }
        .modal-close { font-size: 28px; cursor: pointer; color: #999; }
        .modal-close:hover { color: #000; }
        .modal-body { padding: 20px; }
    </style>
function switchTab(name, btn) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.getElementById('tab-' + name).classList.add('active');
    btn.classList.add('active');
}

// Status Modal Functions
function openStatusModal(reportId, currentStatus, adminNotes) {
    document.getElementById('report_id').value = reportId;
    document.getElementById('new_status').value = currentStatus;
    document.getElementById('admin_notes').value = adminNotes;
    document.getElementById('status-modal').style.display = 'flex';
}

function closeStatusModal() {
    document.getElementById('status-modal').style.display = 'none';
}

// Review Modal Functions
function openReviewModal(reportId, reportData) {
    const modal = document.getElementById('review-modal');
    const content = document.getElementById('review-content');
    
    const typeEmojis = {
        'Air': '🌫️',
        'Water': '💧',
        'Noise': '🔊',
        'Waste': '🗑️',
        'Chemical': '☢️',
        'Soil': '⛰️',
        'Other': '⚠️'
    };
    
    const severityEmojis = {
        'Low': '🟢',
        'Medium': '🟡',
        'High': '🔴'
    };
    
    const typeEmoji = typeEmojis[reportData.pollution_type] || '•';
    const sevEmoji = severityEmojis[reportData.severity_level] || '•';
    
    let photoHTML = '';
    if (reportData.photo) {
        photoHTML = `<div style="margin: 12px 0;"><img src="uploads/${escapeHtml(reportData.photo)}" style="max-width: 100%; max-height: 300px; border-radius: 6px;"></div>`;
    }
    
    let descHTML = '';
    if (reportData.description) {
        descHTML = `<div style="margin: 12px 0;"><strong>Description:</strong><p>${escapeHtml(reportData.description).replace(/\n/g, '<br>')}</p></div>`;
    }
    
    content.innerHTML = `
        <div style="border-bottom: 1px solid #ddd; padding-bottom: 12px; margin-bottom: 12px;">
            <h3 style="margin: 0 0 8px 0;">${escapeHtml(reportData.title)}</h3>
            <div style="color: #666; font-size: 0.9rem;">
                <div>📅 Submitted: ${new Date(reportData.created_at).toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</div>
                <div>👤 By: <strong>${escapeHtml(reportData.username)}</strong></div>
            </div>
        </div>
        
        <div style="margin-bottom: 12px;">
            <span style="display: inline-block; margin-right: 12px;"><strong>${typeEmoji} Type:</strong> ${escapeHtml(reportData.pollution_type)}</span>
            <span style="display: inline-block;"><strong>${sevEmoji} Severity:</strong> ${escapeHtml(reportData.severity_level)}</span>
        </div>
        
        <div style="margin-bottom: 12px;">
            <strong>📍 Location:</strong> ${escapeHtml(reportData.location || 'Not specified')}
        </div>
        
        ${photoHTML}
        ${descHTML}
        
        <div style="margin-top: 16px; padding-top: 12px; border-top: 1px solid #ddd;">
            <strong>📝 Admin Notes:</strong>
            <p>${reportData.admin_notes ? escapeHtml(reportData.admin_notes).replace(/\n/g, '<br>') : '<em style="color: #999;">None yet</em>'}</p>
        </div>
    `;
    
    // Store report ID for validation
    document.getElementById('validation_report_id').value = reportId;
    
    modal.style.display = 'flex';
}

function closeReviewModal() {
    document.getElementById('review-modal').style.display = 'none';
}

// Validation Modal Functions
function openValidationModal() {
    document.getElementById('review-modal').style.display = 'none';
    document.getElementById('validation-modal').style.display = 'flex';
}

function closeValidationModal() {
    document.getElementById('validation-modal').style.display = 'none';
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Close modal when clicking outside of it
window.onclick = function(event) {
    const modal = document.getElementById('status-modal');
    if (event.target === modal) {
        modal.style.display = 'none';
    }
}
</script>
</body>
</html>