<?php
require 'config.php';

$user_id = $_SESSION['user_id'];
$error   = "";
$success = "";

// ---- Handle report submission ----
if (isset($_POST['submit_report'])) {
    $title            = trim($_POST['title']);
    $pollution_type   = trim($_POST['pollution_type']);
    $severity_level   = trim($_POST['severity_level']);
    $description      = trim($_POST['description']);
    $location         = trim($_POST['location']);
    $latitude         = trim($_POST['latitude']);
    $longitude        = trim($_POST['longitude']);
    $photo            = null;

    if (empty($title)) {
        $error = "Report title is required.";
    } elseif (empty($pollution_type)) {
        $error = "Please select a pollution type.";
    } elseif (empty($severity_level)) {
        $error = "Please select a severity level.";
    } else {
        if (!empty($_FILES['photo']['name'])) {
            $allowed = ['jpg','jpeg','png','gif','webp'];
            $ext     = strtolower(pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION));

            if (!in_array($ext, $allowed)) {
                $error = "Only image files are allowed (jpg, png, gif, webp).";
            } elseif ($_FILES['photo']['size'] > 5 * 1024 * 1024) {
                $error = "Photo must be under 5MB.";
            } else {
                if (!is_dir('uploads')) mkdir('uploads', 0755, true);
                $filename = uniqid('report_') . '.' . $ext;
                move_uploaded_file($_FILES['photo']['tmp_name'], 'uploads/' . $filename);
                $photo = $filename;
            }
        }

        if (empty($error)) {
            $stmt = $conn->prepare("
                INSERT INTO reports (user_id, title, pollution_type, severity_level, description, photo, location, latitude, longitude)
                VALUES (:uid, :title, :ptype, :severity, :desc, :photo, :loc, :lat, :lng)
            ");
            $stmt->execute([
                ':uid'      => $user_id,
                ':title'    => $title,
                ':ptype'    => $pollution_type,
                ':severity' => $severity_level,
                ':desc'     => $description,
                ':photo'    => $photo,
                ':loc'      => $location,
                ':lat'      => $latitude ?: null,
                ':lng'      => $longitude ?: null,
            ]);
            $success = "Report submitted! It will appear after admin review.";
        }
    }
}

// ---- Handle forum post ----
if (isset($_POST['post_forum'])) {
    $content = trim($_POST['content']);
    if (!empty($content)) {
        $stmt = $conn->prepare("INSERT INTO posts (user_id, content) VALUES (:uid, :c)");
        $stmt->execute([':uid' => $user_id, ':c' => $content]);
        header("Location: userDashboard.php#forum");
        exit();
    }
}

// ---- Handle filters ----
$filter_type     = isset($_GET['filter_type']) ? trim($_GET['filter_type']) : '';
$filter_severity = isset($_GET['filter_severity']) ? trim($_GET['filter_severity']) : '';
$filter_location = isset($_GET['filter_location']) ? trim($_GET['filter_location']) : '';
$filter_keyword  = isset($_GET['filter_keyword']) ? trim($_GET['filter_keyword']) : '';
$filter_date_from = isset($_GET['filter_date_from']) ? trim($_GET['filter_date_from']) : '';
$filter_date_to   = isset($_GET['filter_date_to']) ? trim($_GET['filter_date_to']) : '';

// ---- Fetch data ----
$stmt = $conn->prepare("SELECT * FROM reports WHERE user_id = :uid ORDER BY created_at DESC");
$stmt->execute([':uid' => $user_id]);
$my_reports = $stmt->fetchAll();

// Build dynamic query for approved reports with filters
$where_conditions = ["r.status = 'approved'"];
$params = [];

if (!empty($filter_type)) {
    $where_conditions[] = "r.pollution_type = :type";
    $params[':type'] = $filter_type;
}

if (!empty($filter_severity)) {
    $where_conditions[] = "r.severity_level = :severity";
    $params[':severity'] = $filter_severity;
}

if (!empty($filter_location)) {
    $where_conditions[] = "r.location LIKE :location";
    $params[':location'] = '%' . $filter_location . '%';
}

if (!empty($filter_keyword)) {
    $where_conditions[] = "(r.title LIKE :keyword OR r.description LIKE :keyword)";
    $params[':keyword'] = '%' . $filter_keyword . '%';
}

if (!empty($filter_date_from)) {
    $where_conditions[] = "DATE(r.created_at) >= :date_from";
    $params[':date_from'] = $filter_date_from;
}

if (!empty($filter_date_to)) {
    $where_conditions[] = "DATE(r.created_at) <= :date_to";
    $params[':date_to'] = $filter_date_to;
}

$where_clause = implode(" AND ", $where_conditions);

$stmt = $conn->prepare("
    SELECT r.*, u.username
    FROM reports r
    JOIN users u ON r.user_id = u.id
    WHERE $where_clause
    ORDER BY r.created_at DESC
");
$stmt->execute($params);
$approved_reports = $stmt->fetchAll();

// Get filter counts for display
$stmt_count = $conn->prepare("
    SELECT COUNT(*) as total FROM reports r
    WHERE r.status = 'approved'
");
$stmt_count->execute();
$total_approved = $stmt_count->fetch()['total'];

$has_active_filters = !empty($filter_type) || !empty($filter_severity) || 
                      !empty($filter_location) || !empty($filter_keyword) || 
                      !empty($filter_date_from) || !empty($filter_date_to);

$stmt = $conn->prepare("
    SELECT p.*, u.username
    FROM posts p
    JOIN users u ON p.user_id = u.id
    ORDER BY p.created_at DESC
    LIMIT 50
");
$stmt->execute();
$forum_posts = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard — AirWatch</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
</head>
<body>
<div class="container">

    <div class="topnav">
        <div class="brand">🌿 AirWatch</div>
        <div class="user-info">
            👤 <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
            &nbsp;|&nbsp;
            <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
        </div>
    </div>

    <!-- AQI Widget -->
    <div class="aqi-widget">
        <div class="aqi-circle" id="aqi-circle">
            <div class="aqi-num" id="aqi-num">—</div>
            <div class="aqi-label">AQI</div>
        </div>
        <div class="aqi-details">
            <h3>🌍 Air Quality — <span id="aqi-city">Loading...</span></h3>
            <div class="aqi-status-text" id="aqi-status">Fetching data...</div>
            <p id="aqi-advice"></p>
            <p class="text-muted">
                Source: Open-Meteo (free, no API key) &nbsp;|&nbsp;
                <button onclick="fetchAQI()" style="background:none; border:none; color:#0066cc; cursor:pointer; font-size:0.8rem; padding:0;">↻ Refresh</button>
            </p>
        </div>
    </div>

    <!-- Tabs -->
    <div class="tabs">
        <button class="tab-btn active" onclick="switchTab('submit', this)">📝 Submit Report</button>
        <button class="tab-btn" onclick="switchTab('my', this)">📂 My Reports</button>
        <button class="tab-btn" onclick="switchTab('map', this)">🗺️ Map</button>
        <button class="tab-btn" onclick="switchTab('feed', this)">📢 Community Feed</button>
        <button class="tab-btn" onclick="switchTab('forum', this)" id="forum-tab-btn">💬 Forum</button>
    </div>

    <!-- Tab: Submit Report -->
    <div id="tab-submit" class="tab-content active">
        <div class="card">
            <div class="card-header">Submit a Pollution Report</div>
            <div class="card-body">

                <?php if ($error): ?>
                    <div class="alert"><?php echo $error; ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="success-msg"><?php echo $success; ?></div>
                <?php endif; ?>

                <form method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>Report Title *</label>
                        <input type="text" name="title" placeholder="e.g. Illegal dumping near river" required>
                    </div>
                    <div class="form-group">
                        <label>Pollution Type *</label>
                        <select name="pollution_type" required>
                            <option value="">-- Select Type --</option>
                            <option value="Air">🌫️ Air Pollution</option>
                            <option value="Water">💧 Water Pollution</option>
                            <option value="Noise">🔊 Noise Pollution</option>
                            <option value="Waste">🗑️ Waste Management</option>
                            <option value="Chemical">☢️ Chemical Hazard</option>
                            <option value="Soil">⛰️ Soil Contamination</option>
                            <option value="Other">⚠️ Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Severity Level *</label>
                        <select name="severity_level" required>
                            <option value="">-- Select Level --</option>
                            <option value="Low">🟢 Low</option>
                            <option value="Medium">🟡 Medium</option>
                            <option value="High">🔴 High</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="description" rows="3" placeholder="Describe what you observed..."></textarea>
                    </div>
                    <div class="form-group">
                        <label>Location</label>
                        <input type="text" name="location" placeholder="e.g. Near Burnham Park, Baguio City">
                    </div>
                    <div class="form-group">
                        <label>Photo (optional, max 5MB)</label>
                        <input type="file" name="photo" accept="image/*">
                    </div>

                    <input type="hidden" name="latitude"  id="lat-input">
                    <input type="hidden" name="longitude" id="lng-input">

                    <div class="mb-10">
                        <button type="button" onclick="getLocation()" class="btn btn-secondary">
                            📍 Use My Current Location
                        </button>
                        <span id="gps-status" class="text-muted">&nbsp;</span>
                    </div>

                    <div class="form-footer">
                        <span></span>
                        <button type="submit" name="submit_report" class="btn btn-primary">Submit Report</button>
                    </div>
                </form>

            </div>
        </div>
    </div>

    <!-- Tab: My Reports -->
    <div id="tab-my" class="tab-content">
        <div class="card">
            <div class="card-header">My Reports — Track Your Progress</div>
            <div class="card-body">
                <?php if (empty($my_reports)): ?>
                    <p class="text-muted" style="padding: 16px; text-align: center;">You haven't submitted any reports yet.</p>
                <?php else: ?>
                    <?php foreach ($my_reports as $r): ?>
                    <div style="border: 1px solid #ddd; border-radius: 6px; padding: 14px; margin-bottom: 12px; background-color: #fafafa;">
                        <div style="display: flex; justify-content: space-between; align-items: start;">
                            <div>
                                <h3 style="margin: 0 0 6px 0; font-size: 1rem;">
                                    <?php echo htmlspecialchars($r['title']); ?>
                                </h3>
                                <div style="font-size: 0.85rem; color: #666; margin-bottom: 8px;">
                                    <div>📍 <?php echo htmlspecialchars($r['location'] ?? 'No location specified'); ?></div>
                                    <div>📅 <?php echo date('M d, Y g:i A', strtotime($r['created_at'])); ?></div>
                                    <div style="margin-top: 4px;">
                                        <span style="display: inline-block; margin-right: 10px;">
                                            <?php 
                                                $types = ['Air' => '🌫️', 'Water' => '💧', 'Noise' => '🔊', 'Waste' => '🗑️', 'Chemical' => '☢️', 'Soil' => '⛰️', 'Other' => '⚠️'];
                                                $type = $r['pollution_type'] ?? 'Other';
                                                echo ($types[$type] ?? '•') . ' ' . htmlspecialchars($type);
                                            ?>
                                        </span>
                                        <span>
                                            <?php 
                                                $severities = ['Low' => '🟢', 'Medium' => '🟡', 'High' => '🔴'];
                                                $sev = $r['severity_level'] ?? 'Medium';
                                                echo ($severities[$sev] ?? '•') . ' ' . htmlspecialchars($sev);
                                            ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div style="text-align: right;">
                                <div style="margin-bottom: 8px;">
                                    <?php 
                                        $status = $r['status'];
                                        $status_display = [
                                            'pending' => ['⏳ Pending', '#ff9800'],
                                            'under_investigation' => ['🔍 Under Investigation', '#2196f3'],
                                            'action_taken' => ['✅ Action Taken', '#4caf50'],
                                            'resolved' => ['🎯 Resolved', '#8bc34a'],
                                            'rejected' => ['❌ Rejected', '#f44336'],
                                            'approved' => ['✨ Approved', '#9c27b0']
                                        ];
                                        $display = $status_display[$status] ?? ['Unknown', '#999'];
                                    ?>
                                    <span style="display: inline-block; padding: 6px 12px; background-color: <?php echo $display[1]; ?>; color: white; border-radius: 4px; font-weight: bold; font-size: 0.85rem;">
                                        <?php echo $display[0]; ?>
                                    </span>
                                </div>
                            </div>
                        </div>

                        <!-- Status Progress Indicator -->
                        <div style="margin-top: 12px; padding-top: 12px; border-top: 1px solid #ddd;">
                            <div style="font-size: 0.75rem; color: #999; margin-bottom: 6px; font-weight: bold;">PROGRESS</div>
                            <div style="display: flex; align-items: center; gap: 4px; font-size: 0.8rem;">
                                <span style="<?php echo ($status !== 'pending') ? 'color: #4caf50; font-weight: bold;' : 'color: #ccc;' ?>">Submitted</span>
                                <span style="color: #ccc;">→</span>
                                <span style="<?php echo in_array($status, ['under_investigation', 'action_taken', 'resolved']) ? 'color: #4caf50; font-weight: bold;' : 'color: #ccc;' ?>">Investigating</span>
                                <span style="color: #ccc;">→</span>
                                <span style="<?php echo in_array($status, ['action_taken', 'resolved']) ? 'color: #4caf50; font-weight: bold;' : 'color: #ccc;' ?>">Action</span>
                                <span style="color: #ccc;">→</span>
                                <span style="<?php echo ($status === 'resolved') ? 'color: #4caf50; font-weight: bold;' : 'color: #ccc;' ?>">Resolved</span>
                            </div>
                        </div>

                        <!-- Admin Notes -->
                        <?php if (!empty($r['admin_notes'])): ?>
                        <div style="margin-top: 12px; padding: 10px; background-color: #e3f2fd; border-left: 4px solid #2196f3; border-radius: 3px;">
                            <div style="font-size: 0.75rem; color: #1976d2; font-weight: bold; margin-bottom: 4px;">📝 ADMIN UPDATE</div>
                            <div style="font-size: 0.9rem; color: #333;">
                                <?php echo nl2br(htmlspecialchars($r['admin_notes'])); ?>
                            </div>
                        </div>
                        <?php else: ?>
                            <?php if ($status === 'pending'): ?>
                            <div style="margin-top: 12px; padding: 10px; background-color: #fff3e0; border-left: 4px solid #ff9800; border-radius: 3px;">
                                <div style="font-size: 0.85rem; color: #e65100;">
                                    ⏳ Your report is pending review. You'll receive updates here soon.
                                </div>
                            </div>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Tab: Map -->
    <div id="tab-map" class="tab-content">
        <div class="card">
            <div class="card-header">🗺️ Report Map — Approved Reports</div>
            <div class="card-body">
                <div id="report-map"></div>
                <p class="text-muted mt-10">
                    Showing <?php echo count($approved_reports); ?> approved report(s). Click a pin to view details.
                </p>
            </div>
        </div>
    </div>

    <!-- Tab: Community Feed -->
    <div id="tab-feed" class="tab-content">
        <h3 style="margin-bottom: 14px;">📢 Approved Community Reports</h3>

        <!-- Filter Panel -->
        <div class="card" style="margin-bottom: 16px; background-color: #f9f9f9;">
            <div class="card-header" style="background-color: #f0f0f0;">🔍 Search & Filter Reports</div>
            <div class="card-body">
                <form id="filter-form" style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
                    
                    <div class="form-group">
                        <label>Pollution Type</label>
                        <select id="filter_type" name="filter_type" onchange="applyFilters()">
                            <option value="">-- All Types --</option>
                            <option value="Air" <?php echo $filter_type === 'Air' ? 'selected' : ''; ?>>🌫️ Air Pollution</option>
                            <option value="Water" <?php echo $filter_type === 'Water' ? 'selected' : ''; ?>>💧 Water Pollution</option>
                            <option value="Noise" <?php echo $filter_type === 'Noise' ? 'selected' : ''; ?>>🔊 Noise Pollution</option>
                            <option value="Waste" <?php echo $filter_type === 'Waste' ? 'selected' : ''; ?>>🗑️ Waste Management</option>
                            <option value="Chemical" <?php echo $filter_type === 'Chemical' ? 'selected' : ''; ?>>☢️ Chemical Hazard</option>
                            <option value="Soil" <?php echo $filter_type === 'Soil' ? 'selected' : ''; ?>>⛰️ Soil Contamination</option>
                            <option value="Other" <?php echo $filter_type === 'Other' ? 'selected' : ''; ?>>⚠️ Other</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Severity Level</label>
                        <select id="filter_severity" name="filter_severity" onchange="applyFilters()">
                            <option value="">-- All Levels --</option>
                            <option value="Low" <?php echo $filter_severity === 'Low' ? 'selected' : ''; ?>>🟢 Low</option>
                            <option value="Medium" <?php echo $filter_severity === 'Medium' ? 'selected' : ''; ?>>🟡 Medium</option>
                            <option value="High" <?php echo $filter_severity === 'High' ? 'selected' : ''; ?>>🔴 High</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Location</label>
                        <input type="text" id="filter_location" name="filter_location" 
                               placeholder="e.g. Burnham Park, Baguio" 
                               value="<?php echo htmlspecialchars($filter_location); ?>"
                               oninput="applyFilters()">
                    </div>

                    <div class="form-group">
                        <label>Keyword Search</label>
                        <input type="text" id="filter_keyword" name="filter_keyword" 
                               placeholder="Search title or description..." 
                               value="<?php echo htmlspecialchars($filter_keyword); ?>"
                               oninput="applyFilters()">
                    </div>

                    <div class="form-group">
                        <label>From Date</label>
                        <input type="date" id="filter_date_from" name="filter_date_from" 
                               value="<?php echo htmlspecialchars($filter_date_from); ?>"
                               onchange="applyFilters()">
                    </div>

                    <div class="form-group">
                        <label>To Date</label>
                        <input type="date" id="filter_date_to" name="filter_date_to" 
                               value="<?php echo htmlspecialchars($filter_date_to); ?>"
                               onchange="applyFilters()">
                    </div>

                    <div style="grid-column: 1 / -1; display: flex; gap: 8px;">
                        <button type="button" onclick="clearFilters()" class="btn btn-secondary">✕ Clear Filters</button>
                    </div>
                </form>

                <div id="active-filters-container"></div>
            </div>
        </div>

        <!-- Results Container (AJAX-loaded) -->
        <div id="results-container">
            <div id="results-count" style="margin-bottom: 8px; font-size: 0.95rem; color: #666;">
                Found <strong><?php echo count($approved_reports); ?></strong> report(s)
            </div>
            <div id="reports-list">
                <?php if (empty($approved_reports)): ?>
                    <p class="text-muted">No reports match your filters. Try adjusting your search criteria.</p>
                <?php else: ?>
                    <?php foreach ($approved_reports as $r): ?>
                    <div class="feed-card">
                        <div class="meta">
                            Posted by <strong><?php echo htmlspecialchars($r['username']); ?></strong>
                            &nbsp;·&nbsp; <?php echo date('M d, Y g:i A', strtotime($r['created_at'])); ?>
                            <?php if ($r['location']): ?>
                                &nbsp;·&nbsp; 📍 <?php echo htmlspecialchars($r['location']); ?>
                            <?php endif; ?>
                        </div>
                        <div class="feed-title"><?php echo htmlspecialchars($r['title']); ?></div>
                        <div style="margin: 8px 0; font-size: 0.85rem;">
                            <span style="display: inline-block; margin-right: 12px;">
                                <?php 
                                    $types = [
                                        'Air' => '🌫️',
                                        'Water' => '💧',
                                        'Noise' => '🔊',
                                        'Waste' => '🗑️',
                                        'Chemical' => '☢️',
                                        'Soil' => '⛰️',
                                        'Other' => '⚠️'
                                    ];
                                    $type = $r['pollution_type'] ?? 'Other';
                                    echo ($types[$type] ?? '•') . ' ' . htmlspecialchars($type);
                                ?>
                            </span>
                            <span style="display: inline-block;">
                                <?php 
                                    $severities = [
                                        'Low' => '🟢',
                                        'Medium' => '🟡',
                                        'High' => '🔴'
                                    ];
                                    $severity = $r['severity_level'] ?? 'Medium';
                                    echo ($severities[$severity] ?? '•') . ' ' . htmlspecialchars($severity);
                                ?>
                            </span>
                        </div>
                        <?php if ($r['description']): ?>
                            <div class="feed-desc"><?php echo nl2br(htmlspecialchars($r['description'])); ?></div>
                        <?php endif; ?>
                        <?php if ($r['photo']): ?>
                            <img src="uploads/<?php echo htmlspecialchars($r['photo']); ?>" alt="report photo">
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Tab: Forum -->
    <div id="tab-forum" class="tab-content">
        <div class="card" style="margin-bottom: 16px;">
            <div class="card-header">💬 Community Forum</div>
            <div class="card-body">
                <form method="POST">
                    <div class="form-group">
                        <label>Share your thoughts, tips, or concerns</label>
                        <textarea name="content" rows="3" placeholder="Write something..." required></textarea>
                    </div>
                    <div style="text-align: right;">
                        <button type="submit" name="post_forum" class="btn btn-primary">Post</button>
                    </div>
                </form>
            </div>
        </div>

        <?php if (empty($forum_posts)): ?>
            <p class="text-muted">No posts yet. Be the first to share!</p>
        <?php else: ?>
        <?php foreach ($forum_posts as $p): ?>
        <div class="forum-post">
            <span class="poster"><?php echo htmlspecialchars($p['username']); ?></span>
            <span class="post-time"><?php echo date('M d, Y g:i A', strtotime($p['created_at'])); ?></span>
            <div class="post-body"><?php echo nl2br(htmlspecialchars($p['content'])); ?></div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>

</div>

<script>
// Tab switching
function switchTab(name, btn) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.getElementById('tab-' + name).classList.add('active');
    btn.classList.add('active');
    if (name === 'map') initMap();
}

if (window.location.hash === '#forum') {
    document.getElementById('forum-tab-btn').click();
}

// GPS
function getLocation() {
    const status = document.getElementById('gps-status');
    if (!navigator.geolocation) {
        status.textContent = "Geolocation not supported.";
        return;
    }
    status.textContent = "Getting location...";
    navigator.geolocation.getCurrentPosition(
        pos => {
            document.getElementById('lat-input').value = pos.coords.latitude;
            document.getElementById('lng-input').value = pos.coords.longitude;
            status.textContent = `✅ (${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)})`;
        },
        () => { status.textContent = "Could not get location."; }
    );
}

// Leaflet Map
let mapInitialized = false;

function initMap() {
    if (mapInitialized) return;
    mapInitialized = true;

    const map = L.map('report-map').setView([16.4023, 120.5960], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    const reports = <?php
        $map_data = array_map(function($r) {
            return [
                'title'    => $r['title'],
                'username' => $r['username'],
                'location' => $r['location'] ?? '',
                'lat'      => $r['latitude'],
                'lng'      => $r['longitude'],
            ];
        }, array_filter($approved_reports, fn($r) => $r['latitude'] && $r['longitude']));
        echo json_encode(array_values($map_data));
    ?>;

    reports.forEach(r => {
        L.marker([r.lat, r.lng]).addTo(map)
         .bindPopup(`<strong>${r.title}</strong><br>By: ${r.username}<br>${r.location}`);
    });
}

// AQI Widget
function fetchAQI() {
    document.getElementById('aqi-status').textContent = "Fetching...";
    const fallbackLat = 16.4023, fallbackLng = 120.5960, fallbackCity = "Baguio City";

    function loadAQI(lat, lng, city) {
        const url = `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lng}&current=us_aqi`;
        fetch(url)
            .then(res => res.json())
            .then(data => {
                const aqi = data.current?.us_aqi;
                document.getElementById('aqi-city').textContent = city;
                document.getElementById('aqi-num').textContent  = aqi ?? '—';

                let color, status, advice;
                if (aqi == null)      { color = '#aaa';     status = 'No data';                          advice = ''; }
                else if (aqi <= 50)   { color = '#28a745';  status = '😊 Good';                          advice = 'Air quality is satisfactory.'; }
                else if (aqi <= 100)  { color = '#e0a800';  status = '😐 Moderate';                      advice = 'Sensitive groups should limit outdoor exposure.'; }
                else if (aqi <= 150)  { color = '#e67e22';  status = '😷 Unhealthy for Some';            advice = 'Children and elderly should reduce outdoor activity.'; }
                else if (aqi <= 200)  { color = '#c0392b';  status = '⚠️ Unhealthy';                     advice = 'Everyone may experience effects. Wear a mask outdoors.'; }
                else if (aqi <= 300)  { color = '#9b59b6';  status = '🚨 Very Unhealthy';                advice = 'Avoid prolonged outdoor exposure.'; }
                else                  { color = '#7f0000';  status = '☠️ Hazardous';                     advice = 'Stay indoors. Health alert for everyone.'; }

                const circle = document.getElementById('aqi-circle');
                circle.style.borderColor = color;
                circle.style.color = color;
                document.getElementById('aqi-status').textContent = status;
                document.getElementById('aqi-status').style.color = color;
                document.getElementById('aqi-advice').textContent = advice;
            })
            .catch(() => {
                document.getElementById('aqi-status').textContent = 'Could not load AQI data.';
                document.getElementById('aqi-city').textContent = city;
            });
    }

    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            pos => loadAQI(pos.coords.latitude, pos.coords.longitude, "Your Location"),
            ()  => loadAQI(fallbackLat, fallbackLng, fallbackCity)
        );
    } else {
        loadAQI(fallbackLat, fallbackLng, fallbackCity);
    }
}

fetchAQI();

// ========== AJAX SEARCH & FILTER ==========

// Debounce function to avoid excessive requests
let filterTimeout;
function applyFilters() {
    clearTimeout(filterTimeout);
    filterTimeout = setTimeout(() => {
        const filterType = document.getElementById('filter_type').value;
        const filterSeverity = document.getElementById('filter_severity').value;
        const filterLocation = document.getElementById('filter_location').value;
        const filterKeyword = document.getElementById('filter_keyword').value;
        const filterDateFrom = document.getElementById('filter_date_from').value;
        const filterDateTo = document.getElementById('filter_date_to').value;

        // Build query string
        const params = new URLSearchParams();
        if (filterType) params.append('filter_type', filterType);
        if (filterSeverity) params.append('filter_severity', filterSeverity);
        if (filterLocation) params.append('filter_location', filterLocation);
        if (filterKeyword) params.append('filter_keyword', filterKeyword);
        if (filterDateFrom) params.append('filter_date_from', filterDateFrom);
        if (filterDateTo) params.append('filter_date_to', filterDateTo);

        // Show loading state
        document.getElementById('results-container').style.opacity = '0.6';

        // Fetch filtered data
        fetch(`search_reports_ajax.php?${params.toString()}`)
            .then(response => response.json())
            .then(data => {
                updateResults(data);
                document.getElementById('results-container').style.opacity = '1';
            })
            .catch(error => {
                console.error('Error:', error);
                document.getElementById('results-container').style.opacity = '1';
            });
    }, 300); // 300ms debounce
}

function updateResults(data) {
    const typeEmojis = {
        'Air': '🌫️',
        'Water': '💧',
        'Noise': '🔊',
        'Waste': '🗑️',
        'Chemical': '☢️',
        'Soil': '⛰️',
        'Other': '⚠️'
    };

    const severityEmojis = {
        'Low': '🟢',
        'Medium': '🟡',
        'High': '🔴'
    };

    // Update active filters display
    const activeContainer = document.getElementById('active-filters-container');
    const filters = data.active_filters;
    if (data.has_active_filters) {
        const activeList = [];
        if (filters.type) activeList.push(`Type: ${filters.type}`);
        if (filters.severity) activeList.push(`Severity: ${filters.severity}`);
        if (filters.location) activeList.push(`Location: ${filters.location}`);
        if (filters.keyword) activeList.push(`Keyword: ${filters.keyword}`);
        if (filters.date_from) activeList.push(`From: ${filters.date_from}`);
        if (filters.date_to) activeList.push(`To: ${filters.date_to}`);
        
        activeContainer.innerHTML = `
            <div style="margin-top: 12px; padding: 8px 12px; background-color: #e8f4f8; border-radius: 4px; font-size: 0.9rem;">
                <strong>Active Filters:</strong> ${activeList.join(' | ')}
            </div>
        `;
    } else {
        activeContainer.innerHTML = '';
    }

    // Update results count
    let countHTML = `Found <strong>${data.total_found}</strong> report(s)`;
    if (data.has_active_filters) {
        countHTML += ` (out of ${data.total_approved} total)`;
    }
    document.getElementById('results-count').innerHTML = countHTML;

    // Update reports list
    const reportsList = document.getElementById('reports-list');
    if (data.reports.length === 0) {
        reportsList.innerHTML = '<p class="text-muted">No reports match your filters. Try adjusting your search criteria.</p>';
        return;
    }

    let html = '';
    data.reports.forEach(report => {
        const typeEmoji = typeEmojis[report.pollution_type] || '•';
        const severityEmoji = severityEmojis[report.severity_level] || '•';
        const date = new Date(report.created_at).toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'short', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });

        let metaHTML = `Posted by <strong>${escapeHtml(report.username)}</strong> &nbsp;·&nbsp; ${date}`;
        if (report.location) {
            metaHTML += ` &nbsp;·&nbsp; 📍 ${escapeHtml(report.location)}`;
        }

        let photoHTML = '';
        if (report.photo) {
            photoHTML = `<img src="uploads/${escapeHtml(report.photo)}" alt="report photo">`;
        }

        let descHTML = '';
        if (report.description) {
            descHTML = `<div class="feed-desc">${escapeHtml(report.description).replace(/\n/g, '<br>')}</div>`;
        }

        html += `
            <div class="feed-card">
                <div class="meta">${metaHTML}</div>
                <div class="feed-title">${escapeHtml(report.title)}</div>
                <div style="margin: 8px 0; font-size: 0.85rem;">
                    <span style="display: inline-block; margin-right: 12px;">
                        ${typeEmoji} ${escapeHtml(report.pollution_type)}
                    </span>
                    <span style="display: inline-block;">
                        ${severityEmoji} ${escapeHtml(report.severity_level)}
                    </span>
                </div>
                ${descHTML}
                ${photoHTML}
            </div>
        `;
    });

    reportsList.innerHTML = html;
}

function clearFilters() {
    document.getElementById('filter_type').value = '';
    document.getElementById('filter_severity').value = '';
    document.getElementById('filter_location').value = '';
    document.getElementById('filter_keyword').value = '';
    document.getElementById('filter_date_from').value = '';
    document.getElementById('filter_date_to').value = '';
    applyFilters();
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
</script>
</body>
</html> 