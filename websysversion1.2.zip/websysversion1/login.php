<?php
require 'config.php';

if (isLoggedIn()) {
    header("Location: " . (isAdmin() ? "adminDashboard.php" : "userDashboard.php"));
    exit();
}

$error = "";

if (isset($_POST['login'])) {
    $email    = trim($_POST['email']);
    $password = trim($_POST['password']);

    if (empty($email) || empty($password)) {
        $error = "Please fill in all fields.";
    } else {
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = :email");
        $stmt->execute([':email' => $email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id']  = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role']     = $user['role'];

            header("Location: " . ($user['role'] === 'admin' ? "adminDashboard.php" : "userDashboard.php"));
            exit();
        } else {
            $error = "Invalid email or password.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — AirWatch</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container-sm">
    <div class="auth-box">

        <div class="auth-logo">
            <h1>🌿 AirWatch</h1>
            <p>Local Pollution Reporting App</p>
        </div>

        <?php if ($error): ?>
            <div class="alert"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" placeholder="you@email.com" required
                       value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" placeholder="Your password" required>
            </div>
            <button type="submit" name="login" class="btn btn-primary btn-full">Log In</button>
        </form>

        <div class="auth-footer">
            No account yet? <a href="registration.php">Register here</a>
        </div>

    </div>
</div>
</body>
</html>
