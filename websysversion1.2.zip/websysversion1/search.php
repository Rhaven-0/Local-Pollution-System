<?php
require 'config.php';

header('Content-Type: application/json');

// Get filter parameters
$filter_type     = isset($_GET['filter_type']) ? trim($_GET['filter_type']) : '';
$filter_severity = isset($_GET['filter_severity']) ? trim($_GET['filter_severity']) : '';
$filter_location = isset($_GET['filter_location']) ? trim($_GET['filter_location']) : '';
$filter_keyword  = isset($_GET['filter_keyword']) ? trim($_GET['filter_keyword']) : '';
$filter_date_from = isset($_GET['filter_date_from']) ? trim($_GET['filter_date_from']) : '';
$filter_date_to   = isset($_GET['filter_date_to']) ? trim($_GET['filter_date_to']) : '';

// Build dynamic query for approved reports with filters
$where_conditions = ["r.status = 'approved'"];
$params = [];

if (!empty($filter_type)) {
    $where_conditions[] = "r.pollution_type = :type";
    $params[':type'] = $filter_type;
}

if (!empty($filter_severity)) {
    $where_conditions[] = "r.severity_level = :severity";
    $params[':severity'] = $filter_severity;
}

if (!empty($filter_location)) {
    $where_conditions[] = "r.location LIKE :location";
    $params[':location'] = '%' . $filter_location . '%';
}

if (!empty($filter_keyword)) {
    $where_conditions[] = "(r.title LIKE :keyword OR r.description LIKE :keyword)";
    $params[':keyword'] = '%' . $filter_keyword . '%';
}

if (!empty($filter_date_from)) {
    $where_conditions[] = "DATE(r.created_at) >= :date_from";
    $params[':date_from'] = $filter_date_from;
}

if (!empty($filter_date_to)) {
    $where_conditions[] = "DATE(r.created_at) <= :date_to";
    $params[':date_to'] = $filter_date_to;
}

$where_clause = implode(" AND ", $where_conditions);

// Fetch filtered reports
$stmt = $conn->prepare("
    SELECT r.*, u.username
    FROM reports r
    JOIN users u ON r.user_id = u.id
    WHERE $where_clause
    ORDER BY r.created_at DESC
");
$stmt->execute($params);
$approved_reports = $stmt->fetchAll();

// Get total count of approved reports
$stmt_total = $conn->prepare("SELECT COUNT(*) as total FROM reports WHERE status = 'approved'");
$stmt_total->execute();
$total_approved = $stmt_total->fetch()['total'];

// Build response
$response = [
    'success' => true,
    'total_found' => count($approved_reports),
    'total_approved' => $total_approved,
    'reports' => $approved_reports,
    'has_active_filters' => !empty($filter_type) || !empty($filter_severity) || 
                           !empty($filter_location) || !empty($filter_keyword) || 
                           !empty($filter_date_from) || !empty($filter_date_to),
    'active_filters' => [
        'type' => $filter_type,
        'severity' => $filter_severity,
        'location' => $filter_location,
        'keyword' => $filter_keyword,
        'date_from' => $filter_date_from,
        'date_to' => $filter_date_to
    ]
];

echo json_encode($response);
?>